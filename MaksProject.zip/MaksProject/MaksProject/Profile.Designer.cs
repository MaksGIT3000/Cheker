﻿namespace MaksProject
{
    partial class Profile
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Profile));
            ProfileLabel = new Label();
            Escape = new Button();
            NamaSurnameLabel = new Label();
            GenderLabel = new Label();
            AgeLabel = new Label();
            AddressLabel = new Label();
            EmployeeLabel = new Label();
            richTextBox1 = new RichTextBox();
            richTextBox2 = new RichTextBox();
            richTextBox3 = new RichTextBox();
            richTextBox4 = new RichTextBox();
            richTextBox5 = new RichTextBox();
            button1 = new Button();
            CloseBtn = new Button();
            SuspendLayout();
            // 
            // ProfileLabel
            // 
            ProfileLabel.AutoSize = true;
            ProfileLabel.BackColor = Color.Transparent;
            ProfileLabel.Font = new Font("Segoe UI", 48F, FontStyle.Regular, GraphicsUnit.Point);
            ProfileLabel.Location = new Point(241, 0);
            ProfileLabel.Name = "ProfileLabel";
            ProfileLabel.Size = new Size(306, 86);
            ProfileLabel.TabIndex = 0;
            ProfileLabel.Text = "Профиль";
            // 
            // Escape
            // 
            Escape.AutoSize = true;
            Escape.BackColor = Color.Red;
            Escape.FlatStyle = FlatStyle.Flat;
            Escape.Location = new Point(762, 12);
            Escape.Name = "Escape";
            Escape.Size = new Size(26, 27);
            Escape.TabIndex = 1;
            Escape.Text = "X";
            Escape.UseVisualStyleBackColor = false;
            // 
            // NamaSurnameLabel
            // 
            NamaSurnameLabel.AutoSize = true;
            NamaSurnameLabel.BackColor = Color.Transparent;
            NamaSurnameLabel.Font = new Font("Segoe UI", 27.75F, FontStyle.Regular, GraphicsUnit.Point);
            NamaSurnameLabel.Location = new Point(40, 150);
            NamaSurnameLabel.Name = "NamaSurnameLabel";
            NamaSurnameLabel.Size = new Size(105, 50);
            NamaSurnameLabel.TabIndex = 2;
            NamaSurnameLabel.Text = "ФИО";
            // 
            // GenderLabel
            // 
            GenderLabel.AutoSize = true;
            GenderLabel.BackColor = Color.Transparent;
            GenderLabel.Font = new Font("Segoe UI", 27.75F, FontStyle.Regular, GraphicsUnit.Point);
            GenderLabel.Location = new Point(263, 225);
            GenderLabel.Name = "GenderLabel";
            GenderLabel.Size = new Size(90, 50);
            GenderLabel.TabIndex = 3;
            GenderLabel.Text = "Пол";
            // 
            // AgeLabel
            // 
            AgeLabel.AutoSize = true;
            AgeLabel.BackColor = Color.Transparent;
            AgeLabel.Font = new Font("Segoe UI", 27.75F, FontStyle.Regular, GraphicsUnit.Point);
            AgeLabel.Location = new Point(198, 300);
            AgeLabel.Name = "AgeLabel";
            AgeLabel.Size = new Size(155, 50);
            AgeLabel.TabIndex = 4;
            AgeLabel.Text = "Возраст";
            // 
            // AddressLabel
            // 
            AddressLabel.AutoSize = true;
            AddressLabel.BackColor = Color.Transparent;
            AddressLabel.Font = new Font("Segoe UI", 27.75F, FontStyle.Regular, GraphicsUnit.Point);
            AddressLabel.Location = new Point(66, 375);
            AddressLabel.Name = "AddressLabel";
            AddressLabel.Size = new Size(287, 50);
            AddressLabel.TabIndex = 5;
            AddressLabel.Text = "Адрес доставки";
            // 
            // EmployeeLabel
            // 
            EmployeeLabel.AutoSize = true;
            EmployeeLabel.BackColor = Color.Transparent;
            EmployeeLabel.Font = new Font("Segoe UI", 27.75F, FontStyle.Regular, GraphicsUnit.Point);
            EmployeeLabel.Location = new Point(141, 450);
            EmployeeLabel.Name = "EmployeeLabel";
            EmployeeLabel.Size = new Size(212, 50);
            EmployeeLabel.TabIndex = 6;
            EmployeeLabel.Text = "Должность";
            // 
            // richTextBox1
            // 
            richTextBox1.Font = new Font("Segoe UI", 20.25F, FontStyle.Regular, GraphicsUnit.Point);
            richTextBox1.Location = new Point(151, 150);
            richTextBox1.Name = "richTextBox1";
            richTextBox1.Size = new Size(637, 50);
            richTextBox1.TabIndex = 7;
            richTextBox1.Text = "";
            // 
            // richTextBox2
            // 
            richTextBox2.Font = new Font("Segoe UI", 20.25F, FontStyle.Regular, GraphicsUnit.Point);
            richTextBox2.Location = new Point(359, 225);
            richTextBox2.Name = "richTextBox2";
            richTextBox2.Size = new Size(429, 50);
            richTextBox2.TabIndex = 8;
            richTextBox2.Text = "";
            // 
            // richTextBox3
            // 
            richTextBox3.Font = new Font("Segoe UI", 20.25F, FontStyle.Regular, GraphicsUnit.Point);
            richTextBox3.Location = new Point(359, 300);
            richTextBox3.Name = "richTextBox3";
            richTextBox3.Size = new Size(429, 50);
            richTextBox3.TabIndex = 9;
            richTextBox3.Text = "";
            // 
            // richTextBox4
            // 
            richTextBox4.Font = new Font("Segoe UI", 20.25F, FontStyle.Regular, GraphicsUnit.Point);
            richTextBox4.Location = new Point(359, 375);
            richTextBox4.Name = "richTextBox4";
            richTextBox4.Size = new Size(429, 50);
            richTextBox4.TabIndex = 10;
            richTextBox4.Text = "";
            // 
            // richTextBox5
            // 
            richTextBox5.Font = new Font("Segoe UI", 20.25F, FontStyle.Regular, GraphicsUnit.Point);
            richTextBox5.Location = new Point(359, 450);
            richTextBox5.Name = "richTextBox5";
            richTextBox5.Size = new Size(429, 50);
            richTextBox5.TabIndex = 11;
            richTextBox5.Text = "";
            // 
            // button1
            // 
            button1.AutoSize = true;
            button1.BackColor = Color.Lime;
            button1.FlatStyle = FlatStyle.Flat;
            button1.Font = new Font("Segoe UI", 15.75F, FontStyle.Regular, GraphicsUnit.Point);
            button1.Location = new Point(642, 546);
            button1.Name = "button1";
            button1.Size = new Size(146, 42);
            button1.TabIndex = 12;
            button1.Text = "Сохранить";
            button1.UseVisualStyleBackColor = false;
            // 
            // CloseBtn
            // 
            CloseBtn.AutoSize = true;
            CloseBtn.BackColor = Color.Red;
            CloseBtn.FlatStyle = FlatStyle.Flat;
            CloseBtn.Font = new Font("Segoe UI", 15.75F, FontStyle.Regular, GraphicsUnit.Point);
            CloseBtn.Location = new Point(12, 546);
            CloseBtn.Name = "CloseBtn";
            CloseBtn.Size = new Size(146, 42);
            CloseBtn.TabIndex = 13;
            CloseBtn.Text = "Назад";
            CloseBtn.UseVisualStyleBackColor = false;
            // 
            // Profile
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.DarkGray;
            BackgroundImage = (Image)resources.GetObject("$this.BackgroundImage");
            BackgroundImageLayout = ImageLayout.Center;
            ClientSize = new Size(800, 600);
            ControlBox = false;
            Controls.Add(CloseBtn);
            Controls.Add(button1);
            Controls.Add(richTextBox5);
            Controls.Add(richTextBox4);
            Controls.Add(richTextBox3);
            Controls.Add(richTextBox2);
            Controls.Add(richTextBox1);
            Controls.Add(EmployeeLabel);
            Controls.Add(AddressLabel);
            Controls.Add(AgeLabel);
            Controls.Add(GenderLabel);
            Controls.Add(NamaSurnameLabel);
            Controls.Add(Escape);
            Controls.Add(ProfileLabel);
            FormBorderStyle = FormBorderStyle.None;
            Name = "Profile";
            Text = "Profile";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label ProfileLabel;
        private Button Escape;
        private Label NamaSurnameLabel;
        private Label GenderLabel;
        private Label AgeLabel;
        private Label AddressLabel;
        private Label EmployeeLabel;
        private RichTextBox richTextBox1;
        private RichTextBox richTextBox2;
        private RichTextBox richTextBox3;
        private RichTextBox richTextBox4;
        private RichTextBox richTextBox5;
        private Button button1;
        private Button CloseBtn;
    }
}